## Follow these steps to setup the code 
```
virtualenv venv

source venv/bin/activate

export FLASK_APP="bloglite.py"

flask run
```
